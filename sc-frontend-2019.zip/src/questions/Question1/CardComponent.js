//you are not allowed to import data.json here!!!
import "./CardComponent.css";

import React from "react";
const CardComponent = () => {
  return <div className="q1-card-component">Your Component Here:</div>;
};

export default CardComponent;
