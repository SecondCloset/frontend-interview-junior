import Question1 from "./Question1";
export default Question1;
