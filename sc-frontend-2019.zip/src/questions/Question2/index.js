import Question2 from "./Question2";
export default Question2;
