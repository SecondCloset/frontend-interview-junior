import React from "react";
import "./MyDropdown.scss";

// const CITIES = ["Toronto", "Vancouver", "Hamilton"];

//Build your component here
const MyDropdown = props => {
  return <div className="q3-hooks-dropdown" />;
};

MyDropdown.propTypes = {};

export default MyDropdown;
