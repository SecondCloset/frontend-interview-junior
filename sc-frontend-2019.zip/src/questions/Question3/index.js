import Question3 from "./Question3";
export default Question3;
